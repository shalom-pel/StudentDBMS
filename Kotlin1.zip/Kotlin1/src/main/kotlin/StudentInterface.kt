interface StudentInterface {
    fun addStudent()
    fun editStudent()
    fun deleteStudent()
    fun displayStudent()
}